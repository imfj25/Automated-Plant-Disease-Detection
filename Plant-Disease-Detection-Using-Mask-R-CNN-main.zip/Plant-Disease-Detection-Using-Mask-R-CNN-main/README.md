# Plant-Disease-Detection-Using-Mask-R-CNN

Download mask_rcnn_coco.h5 and paste in your Project folder.

Create dataset folder and paste your dataset there.

### To understand this code, check this vvideo: https://youtu.be/7ECsYizxC9E

![image](https://user-images.githubusercontent.com/60029146/159105041-4445b22d-f0ec-487c-90bc-0504b00b7ea8.png)

![image](https://user-images.githubusercontent.com/60029146/159105059-cf0378a6-26fc-403d-978f-9748cef622fb.png)

![image](https://user-images.githubusercontent.com/60029146/159105064-e9aacb36-50ff-43d2-93b5-8ab0e036ff32.png)



